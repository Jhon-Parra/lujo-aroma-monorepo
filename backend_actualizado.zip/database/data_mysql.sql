-- MySQL dump 10.13  Distrib 8.2.0, for macos13 (arm64)
--
-- Host: 127.0.0.1    Database: perfumissimo_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES (_binary 'ϰ\�\��0J\��','Jhon','Parra ','3105133401','admin@redex.com','$2b$10$57x6RZ0W2O.6le23bpMhDuq8eBl0lBy4MBBaf8sV/PAXKbIsLJP5m','VENTAS','2026-03-11 01:10:38','2026-03-11 02:08:42'),(_binary '}�\�\�\��0J\��','jairo','parra','3105133401','usuario@gamil.com','$2b$10$9.iSHjrXKKYArQGsy/PYSOCVTM7i.0W.i.THcLCOTrPppzYi7ydgy','CUSTOMER','2026-03-11 02:10:34','2026-03-11 02:10:34'),(_binary '�\�(\�\��0J\��','Jhon Jairo','Parra Parra',NULL,'jhonjairoparraparra39@gmail.com','$2b$10$xTNfiFE/tvz8jM4T97Lv/uN1AJf1U1M4L2cFC1AxhZpjJGpFJ0V6q','CUSTOMER','2026-03-11 02:10:57','2026-03-11 02:10:57'),(_binary '\�\�\�\�\�\��0J\��','Administrador','Root',NULL,'admin@perfumissimo.com','$2b$10$StFe1Ih44x8h.2k67B9BouCZd4oHV7yZAAQZqPQUfTy9FhkjXMW/C','SUPERADMIN','2026-03-10 22:09:15','2026-03-11 01:56:01');
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ConfiguracionGlobal`
--

LOCK TABLES `ConfiguracionGlobal` WRITE;
/*!40000 ALTER TABLE `ConfiguracionGlobal` DISABLE KEYS */;
INSERT INTO `ConfiguracionGlobal` VALUES (1,'La Esencia del Lujo','Descubre colecciones exclusivas creadas por maestros perfumistas de todo el mundo.','#c379ac',1,'ENVÍO GRATIS EN PEDIDOS SUPERIORES 4000','2026-03-11 12:13:55','/assets/images/hero_bg.webp');
/*!40000 ALTER TABLE `ConfiguracionGlobal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-11  9:25:21
